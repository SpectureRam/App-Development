const adminData = [
    {
        username:'admin1',
        password:'admin1'
    },
    {
        username:'admin2',
        password:'password2'
    }
];
export default adminData;